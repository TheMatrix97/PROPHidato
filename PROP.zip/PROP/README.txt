NOTA: FET AMB JAVA 8!!

PER JUGAR A HIDATO:
-/EXE
--PROPHidato.jar

PER PROBAR ELS DRIVERS:
-Anar a EXE:
--DriverGestor.jar -> Executable que prova quasi tot.
--DriverGestorSaves.jar -> Executable que prova el sistema de carregar/guardar partides i rankings.
-Usar java -jar nomdriver.jar per executar

PER VEURE EL CODI:
-De les classes:
--Anar a Fonts\Classes
-Dels Drivers:
--Anar a Fonts\drivers
-Dels test:
--Anar a Fonts\test

PER EXECUTAR ELS TEST:
-/EXE/PROPHidatoTestsUnit.jar

PER VEURE ELS HIDATOS DE LA BASE DE DADES:
-Anar a la carpeta BaseDadesHidatos

PER VEURE LA DOCUMENTACIO
-Anar a la carpeta DOCS:
--Basic_Use_Case_Diagram.pdf
--Casos_dus_prop_pdf.pdf
--Estructures_de_dades_utilitzades.pdf
--Explicacio_dels_Algorismes_principals.pdf
--Manual.pdf
--PropUML.pdf

Authors.txt
-Llista dels membres del grup del projecte
