package hidato;



import java.io.*;
import java.util.ArrayList;
/**
 *
 * @author Antonio.Guilera & Marc.Blanca
 */
//Classe singleton
public class Gestor implements Serializable{

    private ArrayList<Ranking> rankings;
    private Partida game;
    private static Gestor Gest;

    //constructora singleton
    private Gestor() {
        this.rankings = new ArrayList<>();
    }

    public static Gestor getSingletonInstance() {
        if (Gest == null){
            Gest = new Gestor();
        }
        return Gest;
    }
    //funció per crear una partida sense tauler
    public void crearPartidaBuida(String nomJugador){
        game = new Partida(nomJugador);
    }

    //funció per crear una partida partint d'un tauler de la BD
    public void crearPartidaBD(String nom, String nomJugador) throws Exception{
        try{
            game = new Partida(nom,nomJugador);
        }catch(Exception e){
            this.game = null;
            throw new Exception();
            //TODO avisar que la partida no es valida
        }
    }
    //funció que utilitza un usuari per fer una jugada d'inserció
    public void ferJugada(int i, int j, int num) throws Utils.ExceptionJugadaNoValida, Utils.ExceptionTaulerResolt {
        if(game != null) {
            try {
                game.fesJugadaIns(i, j, num);

            }catch(Utils.ExceptionTaulerResolt e){
                Time t = game.getTiempo();
                Jugador jug = game.getJugador();
                if(jug != null) { //si lo ha hecho una persona
                    Record r = new Record(t, jug.getNom());
                    boolean exists = false;
                    for(Ranking rank : rankings){ //todo testear
                        if(rank.getConf().equals(game.getConf())){
                            rank.addRecord(r);
                            exists = true;
                            break;

                        }
                    }
                    if(!exists){
                        Ranking rank = new Ranking(game.getConf());
                        rank.addRecord(r);
                        rankings.add(rank);

                    }

                }
                throw new Utils.ExceptionTaulerResolt();

            }
        }
    }
    //funció per eliminar un número del tauler
    public void ferJugadaDel(int i, int j) throws Utils.ExceptionJugadaNoValida {
        if(game != null){
            game.fesJugadaDel(i,j);
        }
    }

    //funció que utilitza l'usuari per demanar ajuda
    public void demanarAjuda() throws Utils.ExceptionTaulerResolt { //Si la maquina posa l'últim número no tens record.
        if(game != null){
            game.pedirAyuda();
        }
    }
    //setter
    public void setPartida(Partida p){
        this.game = p;
    }
    // getters
    public Partida getPartida(){
        return this.game;
    }

    public ArrayList<Ranking> getRankings(){
        return this.rankings;
    }



    //La clase Gestor es de tipo Singleton, es decir q hay solo una instancia de gestor
    //Para conseguir que una clase sea de tipo Singleton necesitamos en primer lugar que su constructor sea privado.
    // De esa forma ningún programa será capaz de construir objetos de esta tipo .
    // En segundo lugar necesitaremos disponer de una variable estatica privada que almacene una referencia al objeto que vamos a crear a traves del constructor .
    // Por ultian método estático publico que se encarga de instanciar el objeto la primera vez y almacenarlo en la variable estática.
}


