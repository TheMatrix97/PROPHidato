package hidato;

public class Main {

    public static void main(String[] args) {
        CtrlPresentacio c = CtrlPresentacio.getSingletonInstance();
        c.iniMenu();
    }

}

